import logo from './logo.svg';
import './App.css';
import Header from './Components/Header/Header';
import Landing_page from './Components/Landing_page/Landing_page';

function App() {
  return (
    <div className="App">
  <Header/>
  <Landing_page/>
    </div>
  );
}

export default App;
